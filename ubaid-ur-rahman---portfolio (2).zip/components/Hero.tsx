
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React from 'react';

const Hero: React.FC = () => {
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    e.preventDefault();
    const element = document.getElementById(targetId);
    if (element) {
      const headerOffset = 85;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
      
      try {
        window.history.pushState(null, '', `#${targetId}`);
      } catch (err) {
        // Ignore
      }
    }
  };

  return (
    <section className="relative w-full h-screen min-h-[800px] overflow-hidden bg-[#D6D1C7]">
      
      {/* Background Image - Earth from Space */}
      <div className="absolute inset-0 w-full h-full">
        <img 
            src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=2000" 
            alt="Software Engineering" 
            className="w-full h-full object-cover grayscale contrast-[1.1] brightness-[0.7]"
        />
        <div className="absolute inset-0 bg-[#2C2A26]/50"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 h-full flex flex-col justify-center items-start text-left px-8 md:px-24">
        <div className="animate-fade-in-up max-w-5xl">
          
          <h1 className="text-5xl md:text-8xl font-serif text-[#F5F2EB] mb-6 leading-tight">
            Ubaid Ur <span className="italic">Rahman</span>
          </h1>
          <div className="inline-block bg-[#F5F2EB] text-[#2C2A26] px-4 py-1 mb-8 text-sm font-bold uppercase tracking-widest">
            Software Engineer
          </div>

          <p className="max-w-xl text-lg md:text-xl text-white/90 font-light leading-relaxed mb-12">
            BS in Software Engineering with 4 years of experience in web development. 
            Specializing in Frontend, WordPress, and SQA. Building efficient, reliable, and user-friendly software solutions.
          </p>
          
          <div className="flex gap-6">
            <a 
                href="#projects" 
                onClick={(e) => handleNavClick(e, 'projects')}
                className="px-8 py-4 bg-[#F5F2EB] text-[#2C2A26] rounded-full text-sm font-semibold uppercase tracking-widest hover:bg-white transition-all duration-500 shadow-lg hover:shadow-xl inline-block"
            >
                View Projects
            </a>
            <a 
                href="#contact" 
                onClick={(e) => handleNavClick(e, 'footer')}
                className="px-8 py-4 border border-[#F5F2EB] text-[#F5F2EB] rounded-full text-sm font-semibold uppercase tracking-widest hover:bg-[#F5F2EB]/10 transition-all duration-500 inline-block"
            >
                Contact Me
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;