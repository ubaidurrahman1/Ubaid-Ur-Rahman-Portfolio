/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React from 'react';
import { Project } from '../types';

interface ProductDetailProps {
  product: Project; // Using 'product' prop name to maintain compatibility with App.tsx state naming for now
  onBack: () => void;
  onAddToCart: (product: Project) => void; // Kept for signature compatibility but unused
}

const ProductDetail: React.FC<ProductDetailProps> = ({ product, onBack }) => {
  return (
    <div className="pt-24 min-h-screen bg-[#F5F2EB] animate-fade-in-up">
      <div className="max-w-[1800px] mx-auto px-6 md:px-12 pb-24">
        
        {/* Breadcrumb / Back */}
        <button 
          onClick={onBack}
          className="group flex items-center gap-2 text-xs font-medium uppercase tracking-widest text-[#A8A29E] hover:text-[#2C2A26] transition-colors mb-12"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 group-hover:-translate-x-1 transition-transform">
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
          </svg>
          Back to Projects
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Left: Content */}
          <div className="lg:col-span-5 flex flex-col justify-start">
             <span className="text-sm font-medium text-[#A8A29E] uppercase tracking-widest mb-4">{product.category}</span>
             <h1 className="text-5xl md:text-6xl font-serif text-[#2C2A26] mb-8 leading-tight">{product.name}</h1>
             
             <p className="text-xl text-[#5D5A53] font-light leading-relaxed mb-8 border-l-2 border-[#2C2A26] pl-6">
               {product.description}
             </p>

             {product.longDescription && (
                 <p className="text-md text-[#5D5A53] font-light leading-relaxed mb-12">
                    {product.longDescription}
                 </p>
             )}

             {product.link && (
                <div className="mb-12">
                    <a 
                        href={product.link} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 bg-[#2C2A26] text-[#F5F2EB] px-6 py-3 text-sm uppercase tracking-widest font-medium hover:bg-[#433E38] transition-colors"
                    >
                        View Project Source
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 6H5.25A2.25 2.25 0 003 8.25v10.5A2.25 2.25 0 005.25 21h10.5A2.25 2.25 0 0018 18.75V10.5m-10.5 6L21 3m0 0h-5.25M21 3v5.25" />
                        </svg>
                    </a>
                </div>
             )}

             <div className="mb-12">
                <h3 className="text-sm font-bold uppercase tracking-widest text-[#2C2A26] mb-6">Tech Stack</h3>
                <div className="flex flex-wrap gap-3">
                    {product.techStack.map(tech => (
                        <span key={tech} className="bg-[#EBE7DE] px-4 py-2 text-sm text-[#5D5A53] rounded-sm">
                            {tech}
                        </span>
                    ))}
                </div>
             </div>

             <div>
                 <h3 className="text-sm font-bold uppercase tracking-widest text-[#2C2A26] mb-6">Key Features</h3>
                 <ul className="space-y-4 text-[#5D5A53] font-light">
                   {product.features.map((feature, idx) => (
                     <li key={idx} className="flex items-start gap-3">
                       <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mt-0.5 flex-shrink-0 text-[#2C2A26]">
                         <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                       </svg>
                       {feature}
                     </li>
                   ))}
                 </ul>
             </div>
          </div>

          {/* Right: Image */}
          <div className="lg:col-span-7">
            <div className="w-full h-[600px] bg-[#EBE7DE] overflow-hidden sticky top-32">
              <img 
                src={product.imageUrl} 
                alt={product.name} 
                className="w-full h-full object-cover animate-fade-in-up"
              />
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default ProductDetail;