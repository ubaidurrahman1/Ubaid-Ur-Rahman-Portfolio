
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React from 'react';
import { TIMELINE_ITEMS } from '../constants';
import { TimelineItem } from '../types';

interface JournalProps {
  onArticleClick: (article: TimelineItem) => void;
}

const Journal: React.FC<JournalProps> = ({ onArticleClick }) => {
  return (
    <section id="experience" className="bg-[#F5F2EB] py-32 px-6 md:px-12">
      <div className="max-w-[1800px] mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-20 pb-8 border-b border-[#D6D1C7]">
            <div>
                <span className="block text-xs font-bold uppercase tracking-[0.2em] text-[#A8A29E] mb-4">Journey</span>
                <h2 className="text-4xl md:text-6xl font-serif text-[#2C2A26]">Experience & Education</h2>
            </div>
        </div>

        <div className="space-y-12">
            {TIMELINE_ITEMS.map((item) => (
                <div key={item.id} className="group cursor-pointer grid grid-cols-1 md:grid-cols-12 gap-8 items-center border-b border-[#D6D1C7]/50 pb-12 last:border-0" onClick={() => onArticleClick(item)}>
                    
                    {/* Date & Type */}
                    <div className="md:col-span-2">
                        <span className="block text-sm font-medium text-[#2C2A26]">{item.date}</span>
                        <span className="text-xs uppercase tracking-widest text-[#A8A29E]">{item.type}</span>
                    </div>

                    {/* Content */}
                    <div className="md:col-span-6">
                        <h3 className="text-3xl font-serif text-[#2C2A26] mb-2 group-hover:underline decoration-1 underline-offset-4">{item.title}</h3>
                        <p className="text-lg text-[#5D5A53] italic mb-4">{item.subtitle}</p>
                        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-[#A8A29E] group-hover:text-[#2C2A26] transition-colors">
                            Read More
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 8.25L21 12m0 0l-3.75 3.75M21 12H3" />
                            </svg>
                        </div>
                    </div>

                    {/* Image */}
                    <div className="md:col-span-4 hidden md:block overflow-hidden h-48 opacity-80 group-hover:opacity-100 transition-opacity">
                        <img 
                            src={item.image} 
                            alt={item.title} 
                            className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700"
                        />
                    </div>
                </div>
            ))}
        </div>
      </div>
    </section>
  );
};

export default Journal;
