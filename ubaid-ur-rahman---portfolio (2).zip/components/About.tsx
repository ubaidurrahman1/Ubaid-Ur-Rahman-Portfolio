/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React from 'react';
import { SKILLS } from '../constants';

const About: React.FC = () => {
  return (
    <section id="about" className="bg-[#EBE7DE]">
      
      {/* Personal Statement */}
      <div className="py-24 px-6 md:px-12 max-w-[1800px] mx-auto flex flex-col md:flex-row items-start gap-16 md:gap-32">
        <div className="md:w-1/3">
          <h2 className="text-4xl md:text-6xl font-serif text-[#2C2A26] leading-tight">
            Focusing on performance <br/> and <span className="italic">usability.</span>
          </h2>
        </div>
        <div className="md:w-2/3 max-w-2xl">
          <p className="text-lg md:text-xl text-[#5D5A53] font-light leading-relaxed mb-8">
            I am a dedicated Software Engineer with a BS in Software Engineering from the City University of Science & IT. I have 4 years of experience in web development, specializing in front-end development and WordPress.
          </p>
          <p className="text-lg md:text-xl text-[#5D5A53] font-light leading-relaxed mb-8">
            Skilled in SQA, manual testing, and delivering high-quality, user-friendly websites. I also have strong programming skills in Python, C#, and C++, enabling me to build efficient and reliable software solutions. I focus on continuous improvement in every project.
          </p>
          
          <div className="mt-12 p-8 bg-[#D6D1C7]/30 border border-[#D6D1C7]">
             <h4 className="text-sm font-bold uppercase tracking-widest text-[#2C2A26] mb-6">Core Competencies</h4>
             <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-[#5D5A53] font-light">
                <li className="flex items-center gap-3">
                    <span className="w-1.5 h-1.5 bg-[#2C2A26] rounded-full"></span>
                    Software Quality Assurance
                </li>
                <li className="flex items-center gap-3">
                    <span className="w-1.5 h-1.5 bg-[#2C2A26] rounded-full"></span>
                    Front-end Development
                </li>
                <li className="flex items-center gap-3">
                    <span className="w-1.5 h-1.5 bg-[#2C2A26] rounded-full"></span>
                    Manual Testing
                </li>
                <li className="flex items-center gap-3">
                    <span className="w-1.5 h-1.5 bg-[#2C2A26] rounded-full"></span>
                    Agile & Scrum
                </li>
             </ul>
          </div>
        </div>
      </div>

      {/* Technical Skills */}
      <div className="bg-[#2C2A26] text-[#F5F2EB] py-24 px-6 md:px-12">
        <div className="max-w-[1800px] mx-auto">
             <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#A8A29E] mb-6 block">Technical Stack</span>
             <h3 className="text-4xl md:text-5xl font-serif mb-16 leading-tight">
               Tools of the trade.
             </h3>

             <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-12">
                
                <div>
                    <h4 className="text-lg font-serif italic mb-6 text-[#A8A29E]">Programming</h4>
                    <ul className="space-y-3 font-light text-white/80">
                        {SKILLS.programming.map(s => <li key={s}>{s}</li>)}
                    </ul>
                </div>

                <div>
                    <h4 className="text-lg font-serif italic mb-6 text-[#A8A29E]">Web Development</h4>
                    <ul className="space-y-3 font-light text-white/80">
                        {SKILLS.web.map(s => <li key={s}>{s}</li>)}
                    </ul>
                </div>

                <div>
                    <h4 className="text-lg font-serif italic mb-6 text-[#A8A29E]">QA & Methodologies</h4>
                    <ul className="space-y-3 font-light text-white/80">
                        {SKILLS.qa_testing.map(s => <li key={s}>{s}</li>)}
                        {SKILLS.methodologies.map(s => <li key={s}>{s}</li>)}
                    </ul>
                </div>

                <div>
                    <h4 className="text-lg font-serif italic mb-6 text-[#A8A29E]">Tools & DB</h4>
                    <ul className="space-y-3 font-light text-white/80">
                        {SKILLS.tools.map(s => <li key={s}>{s}</li>)}
                        {SKILLS.database.map(s => <li key={s}>{s}</li>)}
                    </ul>
                </div>

             </div>
        </div>
      </div>
    </section>
  );
};

export default About;