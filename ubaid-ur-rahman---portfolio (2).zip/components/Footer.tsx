/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React from 'react';

interface FooterProps {
  onLinkClick: (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => void;
}

const Footer: React.FC<FooterProps> = ({ onLinkClick }) => {
  return (
    <footer id="footer" className="bg-[#EBE7DE] pt-24 pb-12 px-6 text-[#5D5A53]">
      <div className="max-w-[1800px] mx-auto grid grid-cols-1 md:grid-cols-12 gap-12">
        
        {/* Contact Info */}
        <div className="md:col-span-4">
          <h4 className="text-3xl font-serif text-[#2C2A26] mb-6">Contact</h4>
          <p className="max-w-sm font-light leading-relaxed mb-8">
            Dedicated to building efficient and reliable software solutions.
          </p>
          <div className="flex flex-col gap-3">
             <a href="mailto:ubaidurrahman834@gmail.com" className="text-lg text-[#2C2A26] hover:underline decoration-1 underline-offset-4">ubaidurrahman834@gmail.com</a>
             <a href="tel:+923449481087" className="text-lg text-[#2C2A26] hover:underline decoration-1 underline-offset-4">+92 344 9481087</a>
             <div className="mt-2">
                <p className="text-sm text-[#5D5A53]">Alla Dad Khel Hoti</p>
                <p className="text-sm text-[#5D5A53]">Mardan, Pakistan</p>
             </div>
          </div>
        </div>

        {/* References */}
        <div className="md:col-span-4">
          <h4 className="font-medium text-[#2C2A26] mb-6 tracking-wide text-sm uppercase">References</h4>
          <div className="space-y-6 font-light text-sm">
            <div>
                <p className="font-medium text-[#2C2A26]">Mr. Kashif Tufail</p>
                <p>Coordinator, BS AI</p>
                <p>Email: kashiftufail.kt@gmail.com</p>
                <p>Cell: +92 322 9008409</p>
            </div>
            <div>
                <p className="font-medium text-[#2C2A26]">Tauseef Alam</p>
                <p>Lecturer</p>
                <p>Email: Alam374@gmail.com</p>
                <p>Cell: +92 346 9010374</p>
            </div>
          </div>
        </div>
        
        {/* Certifications */}
        <div className="md:col-span-4">
          <h4 className="font-medium text-[#2C2A26] mb-6 tracking-wide text-sm uppercase">Certifications</h4>
          <ul className="space-y-4 font-light text-sm">
            <li className="flex justify-between">
                <span>Artificial Intelligence and Machine Learning</span>
                <span className="text-[#A8A29E] text-xs">June 2025</span>
            </li>
            <li className="flex justify-between">
                <span>Programming for Everybody (Python)</span>
                <span className="text-[#A8A29E] text-xs">April 2025</span>
            </li>
            <li className="flex justify-between">
                <span>Introduction to Web Development</span>
                <span className="text-[#A8A29E] text-xs">March 2024</span>
            </li>
            <li className="flex justify-between">
                <span>Introduction to Cloud Computing</span>
                <span className="text-[#A8A29E] text-xs">March 2024</span>
            </li>
            <li className="mt-4 pt-4 border-t border-[#D6D1C7]/50">
                <span className="block font-medium text-[#2C2A26]">Certificate of Appreciation</span>
                <span className="text-xs">Nayatel "Beat the Curve" Competition</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-[1800px] mx-auto mt-20 pt-8 border-t border-[#D6D1C7] flex flex-col md:flex-row justify-between items-center text-xs uppercase tracking-widest opacity-60">
        <p>&copy; 2025 Ubaid Ur Rahman. All Rights Reserved.</p>
        <div className="flex gap-4 mt-4 md:mt-0">
             <a href="#about" onClick={(e) => onLinkClick(e, 'about')} className="hover:text-[#2C2A26]">About</a>
             <a href="#projects" onClick={(e) => onLinkClick(e, 'projects')} className="hover:text-[#2C2A26]">Projects</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;