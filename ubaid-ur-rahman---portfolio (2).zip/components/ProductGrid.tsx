
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React from 'react';
import { PROJECTS } from '../constants';
import { Project } from '../types';
import ProductCard from './ProductCard';

interface ProductGridProps {
  onProductClick: (project: Project) => void;
}

const ProductGrid: React.FC<ProductGridProps> = ({ onProductClick }) => {
  return (
    <section id="projects" className="py-32 px-6 md:px-12 bg-[#F5F2EB]">
      <div className="max-w-[1800px] mx-auto">
        
        {/* Header Area */}
        <div className="flex flex-col items-start mb-20 border-b border-[#D6D1C7] pb-8">
          <span className="block text-xs font-bold uppercase tracking-[0.2em] text-[#A8A29E] mb-4">Portfolio</span>
          <h2 className="text-4xl md:text-6xl font-serif text-[#2C2A26]">Projects</h2>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-20">
          {PROJECTS.map(project => (
            <ProductCard key={project.id} project={project} onClick={onProductClick} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductGrid;
