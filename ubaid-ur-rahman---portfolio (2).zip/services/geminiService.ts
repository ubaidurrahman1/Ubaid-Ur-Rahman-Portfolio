
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import { GoogleGenAI } from "@google/genai";
import { PROJECTS, SKILLS, TIMELINE_ITEMS } from '../constants';

const getSystemInstruction = () => {
  const projectContext = PROJECTS.map(p => 
    `- Project: ${p.name}. Tech: ${p.techStack.join(', ')}. Desc: ${p.description}`
  ).join('\n');

  const skillContext = Object.entries(SKILLS).map(([cat, items]) => 
    `- ${cat}: ${items.join(', ')}`
  ).join('\n');

  const experienceContext = TIMELINE_ITEMS.map(t => 
    `- ${t.title} at ${t.subtitle} (${t.date}). Type: ${t.type}`
  ).join('\n');

  return `You are the AI Assistant for Ubaid Ur Rahman's portfolio website.
  Ubaid is a Software Engineer based in Mardan, Pakistan.
  
  Here is his background:
  
  **Projects:**
  ${projectContext}
  
  **Skills:**
  ${skillContext}
  
  **Experience & Education:**
  ${experienceContext}
  
  **Contact:**
  Email: ubaidurrahman834@gmail.com
  Phone: +92 344 9481087

  Your goal is to answer visitor questions about Ubaid's qualifications, skills, and experience.
  Keep answers professional, concise, and helpful. Adopt a polite and knowledgeable tone.
  If asked about hiring him, encourage the user to contact him via email or phone.`;
};

export const sendMessageToGemini = async (history: {role: string, text: string}[], newMessage: string): Promise<string> => {
  try {
    let apiKey: string | undefined;
    
    try {
      apiKey = process.env.API_KEY;
    } catch (e) {
      console.warn("Accessing process.env failed");
    }
    
    if (!apiKey) {
      return "I'm sorry, I cannot connect to the server right now. (Missing API Key)";
    }

    const ai = new GoogleGenAI({ apiKey });
    
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: getSystemInstruction(),
      },
      history: history.map(h => ({
        role: h.role,
        parts: [{ text: h.text }]
      }))
    });

    const result = await chat.sendMessage({ message: newMessage });
    return result.text;

  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I apologize, but I seem to be having trouble accessing Ubaid's information at the moment.";
  }
};
